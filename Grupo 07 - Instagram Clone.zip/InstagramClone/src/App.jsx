import React from "react";

export default function App() {
  return (
    <div className="flex flex-col md:flex-row items-center justify-center min-h-screen bg-gray-50">
      <div className="hidden md:flex flex-1 justify-end pr-8">
        <div className="h-[580px] w-[250px] bg-gray-200 rounded-2xl flex items-center justify-center text-gray-500">
          Prévia do App
        </div>
      </div>

      <div className="flex flex-col items-center justify-center w-full max-w-sm">
        <div className="border border-gray-300 bg-white p-10 w-full text-center">
          <h1 className="text-4xl font-bold mb-6 text-gray-800">Instagram</h1>

          <form className="flex flex-col space-y-2">
            <input
              type="text"
              placeholder="Número de celular, nome de usuário ou email"
              className="text-sm border border-gray-300 rounded-sm p-2 bg-gray-50 focus:outline-none"
            />
            <input
              type="password"
              placeholder="Senha"
              className="text-sm border border-gray-300 rounded-sm p-2 bg-gray-50 focus:outline-none"
            />
            <button
              type="submit"
              className="bg-[#0095f6] text-white text-sm font-semibold py-1.5 rounded mt-2 hover:bg-blue-600 transition"
            >
              Entrar
            </button>
          </form>

          <div className="flex items-center my-4">
            <div className="flex-1 h-px bg-gray-300"></div>
            <p className="text-gray-500 text-xs mx-3">OU</p>
            <div className="flex-1 h-px bg-gray-300"></div>
          </div>

          <a href="#" className="text-blue-900 text-sm font-semibold mb-4 block">
            Entrar com o Facebook
          </a>

          <a href="#" className="text-xs text-blue-900">
            Esqueceu a senha?
          </a>
        </div>

        <div className="border border-gray-300 bg-white p-5 w-full text-center mt-3">
          <p className="text-sm">
            Não tem uma conta?{" "}
            <a href="#" className="text-[#0095f6] font-semibold">
              Cadastre-se
            </a>
          </p>
        </div>

        <div className="mt-5 text-center">
          <p className="text-sm mb-2">Obtenha o aplicativo.</p>
          <div className="flex justify-center space-x-2">
            <div className="h-10 w-32 bg-gray-200 rounded"></div>
            <div className="h-10 w-32 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
