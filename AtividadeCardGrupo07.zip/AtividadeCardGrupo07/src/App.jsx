import React from 'react'
import ProfileCard from './ProfileCard'

function App() {
  return (
    <div>
      <h1>Cards de Perfil</h1>
      <ProfileCard name="Maria" age={21} isStudent={true} />
      <ProfileCard name="João" age={30} isStudent={false} />
    </div>
  )
}

export default App
